//
//  User+CoreDataClass.swift
//  Covi-Vaccination
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
