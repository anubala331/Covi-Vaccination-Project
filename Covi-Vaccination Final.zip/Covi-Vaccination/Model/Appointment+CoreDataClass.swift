//
//  Appointment+CoreDataClass.swift
//  Covi-Vaccination
////
//

import Foundation
import CoreData

@objc(Appointment)
public class Appointment: NSManagedObject {

}
